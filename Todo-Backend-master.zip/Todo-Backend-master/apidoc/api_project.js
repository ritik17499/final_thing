define({
  "name": "ToDo",
  "version": "0.0.1",
  "description": "Documentation for the ToDo Application",
  "title": "ToDo APIs",
  "url": "http://localhost:3000",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-09-19T11:06:36.330Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
